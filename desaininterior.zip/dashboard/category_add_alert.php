<div class="box box-warning">
            <div class="box-header with-border">
              <h3 class="box-title">Add Category</h3>
            </div>
            <form class="form-horizontal" action="" method="post">
              <div class="box-body">
                <div class="callout callout-warning">
              <i class="icon fa fa-warning"></i> Limit!</br>
              Purchase to get unlimited category. Please contact xxx-xxx-xxx
              
            </div>
              </div>
             
            </form>
          </div>