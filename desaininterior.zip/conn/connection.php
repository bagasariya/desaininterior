<?php
	$server = "localhost";
	$database = "ap";
	$user = "root";
	$password = "";

	mysql_connect($server, $user, $password);
	mysql_select_db($database);
?>